"""VibeItStudio render worker package."""
